<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'myJewellery' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'v0UMpY9I=i`E0OOV9YxJhh>t)Mq;`kT:U8D;a+?$8AH84 zNW;oWM7i:ix>D)&x*' );
define( 'SECURE_AUTH_KEY',  'diO.AyUga@j1TxVfl$:W)*2:]]pr:hV,;Om0qKYw^@7cy!j3H:JM<$6.6b2|E#i|' );
define( 'LOGGED_IN_KEY',    '[XVK6vuI}8/md;AH@poym_x1JKaNv?#,],(lwV4#v A&HIjRav/f:]N@Uku T.(5' );
define( 'NONCE_KEY',        'JicJ|?-GzIAG<tV?X`Y+Kg`,O11KRO3wDk84U2Ynn+l9Deyi.G>=pfSe+~G|Ar>m' );
define( 'AUTH_SALT',        'bqOoH~xFI~E9:G7%!o@^Z~& `nwOe>1=^|dyM<s,%<V4y-bkgJ3DL=3[44uBH|$X' );
define( 'SECURE_AUTH_SALT', 's|-nro-T#}-Oc`fI?Sk&_mgl&Z}4),J^O<Wm1C#Y/u~_2li4]Y/vz7u)27VQ<3Y$' );
define( 'LOGGED_IN_SALT',   'q3>6JJVH]cy=-h}[6{B`=6JA6C<1]!XB8~w^4?<06S1T#6*`G} b~$>!a26`2oOK' );
define( 'NONCE_SALT',       'n40&bA**ozsOG 4Vn!V&rk 6~ }Md^PT6bRPl0jS*1k}*aR-Pqa)D;abG#P4GDr ' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
